public class BulkPurchase implements Discount {

    private final int bulkQuantity;
    private final double bulkPrice;

    public BulkPurchase(int bulkQuantity, double bulkPrice) {
        this.bulkQuantity = bulkQuantity;
        this.bulkPrice = bulkPrice;
    }

    @Override
    public double calculateDiscount(int quantity, double unitPrice) {
        double totalPrice = 0.0;
        int count = quantity;
        while(count >= bulkQuantity){
            totalPrice += bulkPrice;
            count -= bulkQuantity;
        }
        totalPrice += count*unitPrice;
        return (unitPrice * quantity) - totalPrice;
    }
}
