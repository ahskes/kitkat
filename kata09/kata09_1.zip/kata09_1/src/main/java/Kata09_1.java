public class Kata09_1 {

    public static void main(String[] args){
        //https://salithachathuranga94.medium.com/decorator-design-pattern-in-java-1b0931ead0e4

        //Product product = new NItemsForFixedPriceOffer(new BasicProduct("A",30));
        //Product p2= new BuyOneGetOneFreeOffer(new BulkPurchaseDiscountOffer(3,100, new BasicProduct("B", 40)));
        OfferSelector offerSelector = new MaxDiscountSelector();
        Product p1 = new Product("A", 50, offerSelector);
        p1.addSpecialOffer(SpecialOfferFactory.createBulkPurchaseDiscount(3,120));
        p1.addSpecialOffer(SpecialOfferFactory.createBuyOneGetOneFree());

        Product p2 = new Product("B",30, offerSelector);
        p2.addSpecialOffer(SpecialOfferFactory.createPercentageDiscount(10));

        Checkout checkout = new Checkout();
        checkout.scan(p1);
        checkout.scan(p1);
        checkout.scan(p1);
        checkout.scan(p2);
        checkout.scan(p1);
        checkout.scan(p2);
        checkout.scan(p1);

        double totalPrice = checkout.calculateTotal();
        System.out.println("Total Price: "+ totalPrice);


    }
}
