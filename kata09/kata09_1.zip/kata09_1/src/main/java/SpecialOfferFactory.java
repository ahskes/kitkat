public class SpecialOfferFactory {
    public static SpecialOffer createBuyOneGetOneFree(){
        return new SpecialOffer(new BuyOneGetOneFree());
    }

    public static SpecialOffer createBulkPurchaseDiscount(int bulkQuantity, double bulkPrice){
        return new SpecialOffer(new BulkPurchase(bulkQuantity, bulkPrice));
    }

    public static SpecialOffer createPercentageDiscount(double percentage){
        return new SpecialOffer(new PercentageDiscount(percentage));
    }
}
