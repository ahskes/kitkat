import java.util.HashMap;
import java.util.Map;

public class Checkout {

    private Map<Product, Integer> products;

    public Checkout(){
        this.products = new HashMap<>();
    }
    public void scan(Product product){
        scan(product, 1);
    }
    public void scan(Product product, int quantity){
        if(product == null || quantity <= 0) return;

        int currentQuantity = products.getOrDefault(product, 0);
        products.put(product, currentQuantity + quantity);
    }

    public double calculateTotal(){
        int totalPrice = 0;
        for(Map.Entry<Product, Integer> entry : products.entrySet()){
            Product product = entry.getKey();
            int quantity = entry.getValue();
            //if(product == null || quantity <= 0) continue;

            double discount = product.calculateDiscount(quantity);
            double unitPrice = product.getPrice();
            double price = (quantity * unitPrice) - discount;
            totalPrice += price;
        }
        return totalPrice;
    }
}
