public interface Discount {

    public double calculateDiscount(int quantity, double unitPrice);
}
