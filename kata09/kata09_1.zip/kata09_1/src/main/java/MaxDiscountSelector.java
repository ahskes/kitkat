import java.util.List;

public class MaxDiscountSelector implements OfferSelector{
    @Override
    public double executor(int quantity, double price, List<SpecialOffer> specialOffers) {
        double maxDiscount = 0;
        for(SpecialOffer offer: specialOffers){
            double discount = offer.calculateDiscount(quantity, price);
            if(discount > maxDiscount)
                maxDiscount = discount;
        }

        return maxDiscount;
    }
}
