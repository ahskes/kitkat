public class BuyOneGetOneFree implements Discount {

    @Override
    public double calculateDiscount(int quantity, double unitPrice) {
        double discount = ((int)(quantity / 2)) * unitPrice;
        return discount;
    }
}
