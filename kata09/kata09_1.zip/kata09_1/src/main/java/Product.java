import java.util.ArrayList;
import java.util.List;

public class Product {
    private final String sku;

    private double price;

    //Decorator pattern sayesinde buna gerek yok, neden decorator değil injection kullandık
    private List<SpecialOffer> specialOffers;
    private OfferSelector offerSelector;


    public double getPrice() {

        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void addSpecialOffer(SpecialOffer offer){
        specialOffers.add(offer);
    }

    public void removeSpecialOffer(SpecialOffer offer){
        specialOffers.remove(offer);
    }
    public List<SpecialOffer> getSpecialOffers() {
        return specialOffers;
    }

    public void setSpecialOffers(List<SpecialOffer> specialOffers) {
        this.specialOffers = specialOffers;
    }

    public String getSku() {
        return sku;
    }

    public Product(String sku, double price, OfferSelector offerSelector) {
        this.sku = sku;
        this.price = price;
        this.offerSelector = offerSelector;
        this.specialOffers = new ArrayList<>();
    }

    public double calculateDiscount(int quantity){

        return offerSelector.executor(quantity,price,specialOffers);
    }


}
