public class SpecialOffer {
    private Discount discount;

    public SpecialOffer(Discount discount) {
        this.discount = discount;
    }

    public double calculateDiscount(int quantity, double unitPrice){
        return discount.calculateDiscount(quantity, unitPrice);
    }
}
