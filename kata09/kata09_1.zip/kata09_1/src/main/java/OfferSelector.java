import java.util.List;

public interface OfferSelector {
    public double executor(int quantity, double price, List<SpecialOffer> specialOffers);
}
