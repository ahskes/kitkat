public class PercentageDiscount implements Discount {
    private final double percentage;

    public PercentageDiscount(double percentage) {
        this.percentage = percentage;
    }


    @Override
    public double calculateDiscount(int quantity, double unitPrice) {
        double discount = unitPrice * percentage/100 * quantity;
        return discount > 0 ? discount : 0;
    }
}
